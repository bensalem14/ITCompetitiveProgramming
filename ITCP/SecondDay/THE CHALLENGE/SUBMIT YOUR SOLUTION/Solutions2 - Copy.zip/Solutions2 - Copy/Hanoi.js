function han(nbDisc, src, dst, tool) {
  if (nbDisc == 0) {
    return;
  }
  han(nbDisc - 1, src, tool, dst);
  console.log("Move disk " + nbDisc + " from rod " + src + " to rod " + dst);
  han(nbDisc - 1, tool, dst, src);
}
han(3, "A", "C", "B");
