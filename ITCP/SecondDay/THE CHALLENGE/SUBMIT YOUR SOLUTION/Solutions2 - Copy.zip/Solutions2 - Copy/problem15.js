function is_array_sorted(arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] > arr[i + 1]) {
      return false;
    }
  }
  return true;
}
function nrotation(arr) {
  if (is_array_sorted(arr)) return 0;
  else return arr.length - arr.indexOf(Math.min(...arr));
}
console.log([2, 5, 6], nrotation([2, 5, 6]));
