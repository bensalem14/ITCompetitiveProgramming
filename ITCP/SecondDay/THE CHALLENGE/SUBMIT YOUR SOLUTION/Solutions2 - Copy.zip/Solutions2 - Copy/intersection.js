function performIntersection(arr1, arr2) {
  // converting into Set
  const setA = new Set(arr1);
  const setB = new Set(arr2);

  let intersectionResult = [];

  for (let i of setB) {
    if (setA.has(i)) {
      intersectionResult.push(i);
    }
  }

  return intersectionResult;
}

console.log([1, 2], [2, 3, 5], performIntersection([1, 2], [2, 3, 5]));
