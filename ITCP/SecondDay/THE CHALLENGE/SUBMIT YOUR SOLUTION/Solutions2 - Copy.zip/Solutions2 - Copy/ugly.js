function devisors(n) {
  let arr = [1];
  for (let i = 2; i < n; i++) {
    if (n % i == 0) arr.push(i);
  }
  return arr;
}
function Prime(num) {
  for (let i = 2, s = Math.sqrt(num); i <= s; i++)
    if (num % i === 0) return false;
  return num > 1;
}
function ugly(n) {
  if (n == 1) return false;
  return devisors(n)
    .filter((x) => Prime(x))
    .every((x) => [2, 3, 5].includes(x));
}
console.log(1, ugly(1));
console.log(6, ugly(6));
console.log(12, ugly(12));
