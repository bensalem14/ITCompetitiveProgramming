function devisors(n) {
  let arr = [1];
  for (let i = 2; i < n; i++) {
    if (n % i == 0) arr.push(i);
  }
  return arr;
}
function perfect(n) {
  if (n == 1) return false;
  return n == devisors(n).reduce((acc, a) => acc + a);
}
console.log(496, perfect(496));
console.log(28, perfect(28));
console.log(27, perfect(27));
