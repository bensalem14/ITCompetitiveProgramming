const R = 3;
const C = 6;

function formSpiralMatrix(arr, mat) {
  let top = 0,
    bottom = R - 1,
    left = 0,
    right = C - 1;

  let index = 0;

  while (1) {
    if (left > right) break;

    for (let i = left; i <= right; i++) mat[top][i] = arr[index++];

    top++;

    if (top > bottom) break;

    for (let i = top; i <= bottom; i++) mat[i][right] = arr[index++];
    right--;

    if (left > right) break;

    for (let i = right; i >= left; i--) mat[bottom][i] = arr[index++];

    bottom--;

    if (top > bottom) break;

    for (let i = bottom; i >= top; i--) mat[i][left] = arr[index++];

    left++;
  }
}

let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];

let mat = new Array(R);
for (let i = 0; i < R; i++) mat[i] = new Array(C);

formSpiralMatrix(arr, mat);
console.log(mat);
