function longest(arr) {
  return arr.reduce(function (a, b) {
    return a.length > b.length ? a : b;
  });
}
function normalize(str, n) {
  let x = "* " + str;
  while (x.length < n - 1) {
    x += " ";
  }
  return x + "*";
}
function slist(arr) {
  let x = longest(arr).length + 4;
  let v = "";
  for (let i = 0; i < x; i++) v += "*";
  console.log(v);
  for (i of arr) {
    console.log(normalize(i, x));
  }
  console.log(v);
}
slist(["11", "222", "5454"]);
