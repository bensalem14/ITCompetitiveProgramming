function check(arr) {
  return (
    arr.every(function (e, i, a) {
      if (i) return e > a[i - 1];
      else return true;
    }) ||
    arr.every(function (e, i, a) {
      if (i) return e < a[i - 1];
      else return true;
    })
  );
}
console.log([5, 4, 2, 3, 1], check([5, 4, 2, 3, 1]));
console.log([5, 4, 3, 1], check([5, 4, 3, 1]));
