console.log("i love printing & i love ITC");
