function fibo(n) {
  if (n == 0) {
    return 1;
  } else if (n == 1) {
    return 1;
  } else {
    return fibo(n - 2) + fibo(n - 1);
  }
}
function fibo_nums(n) {
  let arr = [];
  for (let i = 0; i < n; i++) {
    arr.push(fibo(i));
  }
  return arr;
}
let n = 5;
console.log(n, fibo_nums(n));
