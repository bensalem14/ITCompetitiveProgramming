function intToChar(int) {
  const code = "A".charCodeAt(0);
  return String.fromCharCode(code + int - 1);
}
function findcolumn(row) {
  let k = 0;
  let str = "";
  if (row < 26) return intToChar(row);
  while (row != 0) {
    str = intToChar((row % 26) + 1) + str;
    row = Math.floor(row / 26);
  }
  return str;
}
console.log(findcolumn(26));
