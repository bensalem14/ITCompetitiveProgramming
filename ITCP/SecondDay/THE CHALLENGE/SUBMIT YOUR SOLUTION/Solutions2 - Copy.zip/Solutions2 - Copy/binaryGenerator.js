function generate(n) {
  let arr = [];
  for (let i = 1; i <= n; i++) {
    arr.push(i.toString(2));
  }
  return arr;
}
console.log(generate(10));
