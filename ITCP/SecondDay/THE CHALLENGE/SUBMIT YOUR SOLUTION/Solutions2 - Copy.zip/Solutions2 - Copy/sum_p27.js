function sum(a, b) {
  return a + b < 100;
}
console.log(1, 6, sum(1, 6));
