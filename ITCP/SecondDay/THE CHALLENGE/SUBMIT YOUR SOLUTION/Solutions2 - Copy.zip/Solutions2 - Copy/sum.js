function addition(i, j) {
  return i + j;
}
console.log(5, 6, addition(5, 6));
