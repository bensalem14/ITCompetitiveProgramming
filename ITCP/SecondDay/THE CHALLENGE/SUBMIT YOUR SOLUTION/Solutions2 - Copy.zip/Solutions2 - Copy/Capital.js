function cap(str) {
  return str.toUpperCase() == str;
}
console.log("AAAa", cap("AAAa"));
console.log("AAA", cap("AAA"));
