function check(year) {
  return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}
console.log("1991", check(1991));
console.log("1992", check(1992));
