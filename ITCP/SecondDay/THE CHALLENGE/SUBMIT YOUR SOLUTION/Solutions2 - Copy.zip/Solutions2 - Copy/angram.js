function angram(str1, str2) {
  return str1.split("").sort().join("") == str2.split("").sort().join("");
}
let str1 = "listen";
let str2 = "silent";
console.log(str1, str2, angram(str1, str2));
str1 = "bar";
str2 = "car";
console.log(str1, str2, angram(str1, str2));
