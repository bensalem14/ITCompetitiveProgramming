function print(n, a, b) {
  for (let i = 1; i <= n; i++) {
    if (i % a == 0 && i % b == 0) console.log("ITCCC");
    else if (i % a == 0) console.log("IT");
    else if (i % b == 0) console.log("CCC");
    else console.log(i);
  }
}
console.log("for 10 : ");
print(10, 2, 3);
